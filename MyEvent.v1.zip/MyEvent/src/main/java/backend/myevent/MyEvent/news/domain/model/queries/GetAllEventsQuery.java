package backend.myevent.MyEvent.news.domain.model.queries;

public record GetAllEventsQuery() {
    public GetAllEventsQuery {

    }
}
