package backend.myevent.MyEvent.news.interfaces.rest.resources;

public record UserResource(String name, String surname, String address, String phone, String correo, String password, String newsApiKey) {
}
