export class Product {
    id!:number;
    title!: string;
    location!: string;
    Price!: number;
    color?: string;
    discount?: number;
    photo!: string;
    detail?:string;
}
